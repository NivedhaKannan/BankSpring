package com.capgemini.bankapp.model;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

@Component
public class Customer {
	
	
	private Integer accNum,funacc;
	
	@NotNull
	private String name;
	private String address;
	private String phnno;
	private String aadharno;
	private String status="My Transactions:";
	private Integer age;
	@Id
	private Integer pin;
	private Double balance;
	private Double amt;
	
	public Customer()
	{

	}
	

	public Integer getFunacc() {
		return funacc;
	}


	public void setFunacc(Integer funacc) {
		this.funacc = funacc;
	}


	public Double getAmt() {
		return amt;
	}


	public void setAmt(Double amt) {
		this.amt = amt;
	}


	public Integer getPin() {
		return pin;
	}


	public void setPin(Integer pin) {
		this.pin = pin;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Integer getAccNum() {
		return accNum;
	}


	public void setAccNum(Integer accNum) {
		this.accNum = accNum;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPhnno() {
		return phnno;
	}


	public void setPhnno(String phnno) {
		this.phnno = phnno;
	}


	public String getAadharno() {
		return aadharno;
	}


	public void setAadharno(String aadharno) {
		this.aadharno = aadharno;
	}


	public Integer getAge() {
		return age;
	}


	public void setAge(Integer age) {
		this.age = age;
	}


	public Double getBalance() {
		return balance;
	}


	public void setBalance(Double balance) {
		this.balance = balance;
	}


	@Override
	public String toString() {
		return "Customer [accNum=" + accNum + ", funacc=" + funacc + ", name=" + name + ", address=" + address
				+ ", phnno=" + phnno + ", aadharno=" + aadharno + ", status=" + status + ", age=" + age + ", pin=" + pin
				+ ", balance=" + balance + ", amt=" + amt + "]";
	}





	

	

}

