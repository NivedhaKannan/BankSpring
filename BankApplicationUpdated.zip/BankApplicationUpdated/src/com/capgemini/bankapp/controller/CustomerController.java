package com.capgemini.bankapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.bankapp.exception.CustomerException;
import com.capgemini.bankapp.model.Customer;
import com.capgemini.bankapp.service.ICustomerService;
@Controller
@RequestMapping(value="/bank")
public class CustomerController {
	@Autowired
	ICustomerService customerService;
	
	//For displaying the main menu
	@RequestMapping(value="/mainmenu")
	public String getCustomerMenu() {
		return "main_menu";
	}
	
	
								/*Create an account*/
	@RequestMapping(value="/preregister" ,method=RequestMethod.GET)
	public ModelAndView customerForm() {
		Customer customer=new Customer();
		return new ModelAndView("apply","customer",customer);
	}
	@RequestMapping(value="/register" ,method=RequestMethod.POST)
	public ModelAndView addCustomer( @ModelAttribute(value="customer")Customer customer) 
	{
		try {
			boolean flag=customerService.createAccount(customer);
			if(flag)
			{
			return new ModelAndView("customer_creation","accountNumber",customer.getAccNum());
			}else
			{
				String result="Account creation failed.!Sorry Try again";
				return new ModelAndView("status","message",result); 
			}
		} catch (CustomerException e) {			
			return new ModelAndView("status","message",e.getMessage());
		}		
	}
	//To display the other services
	@RequestMapping(value="/services")
	public String getServicesmenu() {
		return "services";
	}
								/*Show the balance*/
			//To display the withdrawal form
			@RequestMapping(value="/withdraw")
			public String show_balance()
			{
			return "show_balance";
			}
			
			
			//To get the account number,pin from the form
			@RequestMapping(value="tocontroller" ,method=RequestMethod.POST)
			public ModelAndView show_balance( @RequestParam(value="accNum") Integer accNum,@RequestParam(value="pin")Integer pin)
			{
			try
			{
			double balance=customerService.showBalance(accNum, pin);
			return new ModelAndView("display_pg","balance",balance);
			} catch (CustomerException e) {			
			return new ModelAndView("status","message",e.getMessage());
			}		
			
			}
				
	
	
										/*Withdrawal*/
	//To display the withdrawal form
	@RequestMapping(value="/withdraw")
	public String withdrawForm()
	{
		return "withdraw_deposit";
	}
	
	
	//To get the account number,pin,amount from the form
	@RequestMapping(value="fromwithdrawal" ,method=RequestMethod.POST)
	public ModelAndView withdrawal( @RequestParam(value="accNum") Integer accNum,
			@RequestParam(value="pin")Integer pin,@RequestParam(value="amt")Double amt)
	{
		try
		{
			double balance=customerService.withDraw(accNum, pin, amt);
			return new ModelAndView("display_pg","balance",balance);
		} catch (CustomerException e) {			
			return new ModelAndView("status","message",e.getMessage());
		}		
		
	}
										/*Deposit*/
			//To display the deposit form
			@RequestMapping(value="/deposit")
			public String depositForm()
		{
		return "withdraw_deposit";
		}
		
		
		//To get the account number,pin,amount from the form
		@RequestMapping(value="fromform" ,method=RequestMethod.POST)
		public ModelAndView deposit( @RequestParam(value="accNum") Integer accNum,
		@RequestParam(value="pin")Integer pin,@RequestParam(value="amt")Double amt)
		{
		try
		{
		double balance=customerService.deposit(accNum, pin, amt);
		return new ModelAndView("display_pg","balance",balance);
		} catch (CustomerException e) {			
		return new ModelAndView("status","message",e.getMessage());
		}		

}
		
}
