package com.capgemini.bankapp.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.capgemini.bankapp.dao.ICustomerDao;
import com.capgemini.bankapp.entity.CustomerEntity;
import com.capgemini.bankapp.exception.CustomerException;
import com.capgemini.bankapp.model.Customer;


@Service
public class CustomerServiceImpl implements ICustomerService{
	
	@Autowired
	ICustomerDao customerDAO;
	
	public boolean createAccount(Customer customer)throws CustomerException
	{
		CustomerValidator validator=new CustomerValidator();
		if(validator.validate(customer))
		{
			CustomerEntity CustomerEntity=new CustomerEntity();
			populateCustomerEntity(customer,CustomerEntity);
			return customerDAO.createAccount(CustomerEntity);
			
		}else
			return false;
		
	}
	
	private void populateCustomerEntity(Customer customer, CustomerEntity customerEntity) {
		
		customerEntity.setAccNum();
		customerEntity.setPin();
		customerEntity.setStatus();
		customerEntity.setName(customer.getName());
		customerEntity.setAge(customer.getAge());
		customerEntity.setPhnno(customer.getPhnno());
		customerEntity.setAddress(customer.getAddress());
		customerEntity.setBalance(customer.getBalance());
		customerEntity.setStatus(customer.getStatus());
		
	}

	@Override
	public double withDraw(Integer accNum, Integer pin, Double amt) throws CustomerException {
	
		return customerDAO.withDraw(accNum, pin, amt);
	}


	@Override
	public double deposit(Integer accNum, Integer pin, Double amt) throws CustomerException {
		
		return customerDAO.deposit(accNum, pin, amt);
	}


	@Override
	public double showBalance(Integer accNum, Integer pin) throws CustomerException {
		//customerDAO =new CustomerDAOImpl();
		return customerDAO.showBalance(accNum, pin);
	}


	@Override
	public boolean fundTransfer(Integer accNum, Integer funacc, Double amt, Integer pin) throws CustomerException {
		
		return customerDAO.fundTransfer(accNum, funacc, amt, pin);
	}


	@Override
	public String printTransaction(Integer accNum, Integer pin) throws CustomerException {
		return customerDAO.printTransaction(accNum, pin);
	}



	


}


	
	
	
	


