package com.capgemini.bankapp.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.bankapp.dao.ICustomerDao;
import com.capgemini.bankapp.entity.CustomerEntity;
import com.capgemini.bankapp.exception.CustomerException;
import com.capgemini.bankapp.model.Customer;


@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService{
	
	@Autowired
	ICustomerDao customerDAO;
	
	public Customer createAccount(Customer customer)throws CustomerException
	{
		CustomerValidator validator=new CustomerValidator();
		if(validator.validate(customer)==true)
		{
			CustomerEntity customerEntity=new CustomerEntity();
			populateCustomerEntity(customer,customerEntity);
			customerEntity=customerDAO.createAccount(customerEntity);
			populateCustomerEntity(customerEntity,customer);
		}
		
			return customer;
		
	
		}
	
	private void populateCustomerEntity(CustomerEntity customerEntity, Customer customer) 
	{
	customer.setAccNum(customerEntity.getAccNum());
	customer.setPin(customerEntity.getPin());
	customer.setName(customerEntity.getName());
	customer.setPhnno(customerEntity.getPhnno());
	customer.setStatus(customerEntity.getStatus());
	customer.setAge(customerEntity.getAge());
	customer.setAddress(customerEntity.getAddress());
	customer.setAadharno(customerEntity.getAadharno());
	customer.setBalance(customerEntity.getBalance());
		
	}

	private void populateCustomerEntity(Customer customer, CustomerEntity customerEntity) {
		
		customerEntity.setAccNum();
		customerEntity.setPin();
		customerEntity.setStatus();
		customerEntity.setName(customer.getName());
		customerEntity.setAge(customer.getAge());
		customerEntity.setPhnno(customer.getPhnno());
		customerEntity.setAadharno(customer.getAadharno());
		customerEntity.setAddress(customer.getAddress());
		customerEntity.setBalance(customer.getBalance());
		customerEntity.setStatus(customer.getStatus());
		
	}

	@Override
	public double showBalance(Integer pin) throws CustomerException {
		//customerDAO =new CustomerDAOImpl();
		return customerDAO.showBalance(pin);
	}


	@Override
	public double withDraw(Integer pin, Double amt) throws CustomerException {
	
		return customerDAO.withDraw(pin, amt);
	}


	@Override
	public double deposit(Integer pin, Double amt) throws CustomerException {
		
		return customerDAO.deposit( pin, amt);
	}



	@Override
	public boolean fundTransfer(Integer funacc, Double amt, Integer pin) throws CustomerException {
		
		return customerDAO.fundTransfer(funacc, amt, pin);
	}

/*
	@Override
	public String printTransaction(Integer accNum, Integer pin) throws CustomerException {
		return customerDAO.printTransaction(accNum, pin);
	}*/



	


}


	
	
	
	


