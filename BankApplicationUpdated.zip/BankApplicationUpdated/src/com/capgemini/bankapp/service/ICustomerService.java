package com.capgemini.bankapp.service;

import com.capgemini.bankapp.exception.CustomerException;
import com.capgemini.bankapp.model.Customer;

public interface ICustomerService {
	public Customer createAccount(Customer customer)throws CustomerException;
	public double showBalance(Integer pin)throws CustomerException;
	public double withDraw(Integer pin,Double amt)throws CustomerException;
	public double deposit(Integer pin,Double amt)throws CustomerException;
	
	public boolean fundTransfer(Integer funacc,Double amt,Integer pin)throws CustomerException;
/*	public String printTransaction(Integer pin)throws CustomerException;*/
	
}
