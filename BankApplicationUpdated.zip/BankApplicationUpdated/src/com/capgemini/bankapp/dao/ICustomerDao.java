
package com.capgemini.bankapp.dao;

import com.capgemini.bankapp.entity.CustomerEntity;
import com.capgemini.bankapp.exception.CustomerException;

public interface ICustomerDao 
{
	public boolean createAccount(CustomerEntity customerEntity)throws CustomerException;
	public double showBalance(Integer accNum, Integer pin)throws CustomerException;
	public double withDraw(Integer accNum,Integer pin,Double amt)throws CustomerException;
	public double deposit(Integer accNum,Integer pin,Double amt)throws CustomerException;
	
	public boolean fundTransfer(Integer accNum,Integer funacc,Double amt,Integer pin)throws CustomerException;
	public String printTransaction(Integer accNum,Integer pin)throws CustomerException;
	public boolean validateBalance(Integer accNum,Integer pin,Double amt)throws CustomerException;

}
