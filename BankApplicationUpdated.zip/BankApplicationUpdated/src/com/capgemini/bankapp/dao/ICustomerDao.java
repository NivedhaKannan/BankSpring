
package com.capgemini.bankapp.dao;


import com.capgemini.bankapp.entity.CustomerEntity;
import com.capgemini.bankapp.exception.CustomerException;



public interface ICustomerDao 
{
	public CustomerEntity createAccount(CustomerEntity customerEntity)throws CustomerException;
	public double showBalance(Integer pin)throws CustomerException;
	public double withDraw(Integer pin,Double amt)throws CustomerException;
	public double deposit(Integer pin,Double amt)throws CustomerException;
	
	public boolean fundTransfer(Integer funacc,Double amt,Integer pin)throws CustomerException;
/*	public String printTransaction(Integer pin)throws CustomerException;*/
	public boolean validateBalance(Integer pin,Double amt)throws CustomerException;



}
