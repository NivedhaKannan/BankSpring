function checking()
{

	if (document.myform.userName.value == "") 
	{
		alert("Please fill the User Name");
	}
	else if (document.myform.city.value == "") 
	{
		alert("Please fill the city");
	}
	else if (document.myform.password.value == "")
	{
		alert("Please fill the password");
	}else if((document.myform.gender[0].checked==false)&&(document.myform.gender[1].checked==false))
	{
		alert("Please select a gender");
	}
	else if((document.myform.lang[0].checked==false)&&(document.myform.lang[1].checked==false)&&(document.myform.lang[2].checked==false))
	{
		alert("Please select a language");
	}
	else if (document.myform.number.value == "")
	{
		alert("Please fill My number.");
	}
	else if (document.myform.mobile.value == "")
	{
		alert("Please fill Mobile No.");
	}
	else if (document.myform..value =="" ) 
	{ 
		alert("Please enter Email Id.");
	}

//on valid inputs
	else {

		alert(" completed Successfully.");

	}
}