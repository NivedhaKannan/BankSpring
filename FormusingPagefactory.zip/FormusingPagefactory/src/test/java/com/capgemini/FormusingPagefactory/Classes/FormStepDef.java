package com.capgemini.FormusingPagefactory.Classes;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class FormStepDef {

	private PageFactorypage fact;
	private WebDriver wd;

	@Given("^The user is in the form page$")
	public void the_user_is_in_the_form_page() throws Throwable
	{
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		wd=new ChromeDriver();
		fact = new PageFactorypage(wd);
		wd.get("file:///D:\\New WorkSpace\\FormusingPagefactory\\src\\main\\java\\com\\capgemini\\FormusingPagefactory\\Basicform.html");
	}

	@When("^the name box is empty$")
	public void the_name_box_is_empty() throws Throwable
	{
		fact.setUserName("");

	}

	@When("^the user clicks submit button$")
	public void the_user_clicks_submit_button() throws Throwable 
	{
		fact.setButton();
	}

	@Then("^display the name error message$")
	public void display_the_name_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);//console
		Thread.sleep(2000);
		wd.close();
	}

	@When("^the city box is empty$")
	public void the_city_box_is_empty() throws Throwable 
	{
		fact.setUserName("Nivedha");
		fact.setCity("");
	}

	@Then("^display the city error message$")
	public void display_the_city_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	@When("^the Password text box is empty$")
	public void the_Password_text_box_is_empty() throws Throwable {
		fact.setUserName("Nivedha");
		fact.setCity("Chennai");
		fact.setPassword("");

	}

	@Then("^display the password error message$")
	public void display_the_password_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	@When("^the gender button is not selected$")
	public void the_gender_button_is_not_selected() throws Throwable {
		fact.setUserName("Nivedha");
		fact.setCity("Chennai");
		fact.setPassword("admin");
		/*fact.setRadio_button(null);*/
	}

	@Then("^display the gender error message$")
	public void display_the_gender_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	@When("^the language checkbox is not checked$")
	public void the_language_checkbox_is_not_checked() throws Throwable
	{
		fact.setUserName("Nivedha");
		fact.setCity("Chennai");
		fact.setPassword("admin");
		/*fact.setRadio_button(fact.getRadio_button());
		fact.setCheck_box(null);*/
	}

	@Then("^display the language error message$")
	public void display_the_language_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	
	@When("^the mynumber is not entered$")
	public void the_mynumber_is_not_entered() throws Throwable {
		fact.setUserName("Nivedha");
		fact.setCity("Chennai");
		fact.setPassword("admin");
	/*	fact.setRadio_button(fact.getRadio_button());
		fact.setCheck_box(fact.getCheck_box());*/
		
		fact.setMyNumber("");
	}

	@Then("^display the mynumber error message$")
	public void display_the_mynumber_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(5000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(5000);
		wd.close();
	}

	@When("^the email is not entered$")
	public void the_email_is_not_entered() throws Throwable {
		fact.setUserName("Nivedha");
		fact.setCity("Chennai");
		fact.setPassword("admin");
/*		fact.setRadio_button(fact.getRadio_button());
		fact.setCheck_box(fact.getCheck_box());*/
		fact.setMyNumber("212214107033");
		fact.setEmail("");
	}

	@Then("^display the email error message$")
	public void display_the_email_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(5000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(5000);
		wd.close();
	}

	@When("^the mobilenumber is not entered$")
	public void the_mobilenumber_is_not_entered() throws Throwable {
		fact.setUserName("Nivedha");
		fact.setCity("Chennai");
		fact.setPassword("admin");
		/*fact.setRadio_button(fact.getRadio_button());
		fact.setCheck_box(fact.getCheck_box());*/
		fact.setMyNumber("212214107033");
		fact.setEmail("nivedhak@gmail.com");
		fact.setMobile("");
	}

	@Then("^display the mobilenumber error message$")
	public void display_the_mobilenumber_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(5000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(5000);
		wd.close();
	}
	@When("^all the entered details are valid$")
	public void all_the_entered_details_are_valid() throws Throwable {
		fact.setUserName("Nivedha");
		fact.setCity("Chennai");
		fact.setPassword("admin");
/*		fact.setRadio_button(fact.getRadio_button());
		fact.setCheck_box(fact.getCheck_box());*/
		fact.setEmail("nivedhak@gmail.com");
		fact.setMobile("8754274316");
		fact.setMyNumber("212214107033");
			
	}

	@Then("^display the success page$")
	public void display_the_success_page() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(5000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(5000);
		wd.close();
	}

}
