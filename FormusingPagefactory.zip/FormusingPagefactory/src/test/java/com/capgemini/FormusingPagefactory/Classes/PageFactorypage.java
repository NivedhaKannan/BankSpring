package com.capgemini.FormusingPagefactory.Classes;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageFactorypage
{
	WebDriver driver;


	public PageFactorypage(WebDriver webdriver)
	{
		this.driver=webdriver;
		PageFactory.initElements(driver, this);
	}


	@FindBy(how=How.NAME, using="userName")
	@CacheLookup
	WebElement userName;

	@FindBy(name = "city")
	@CacheLookup
	WebElement city;

	@FindBy(name = "password")
	@CacheLookup
	WebElement password;

/*	@FindBy(name = "gender")
	@CacheLookup
	List<WebElement> radio_button;

	@FindBy(name ="lang")
	@CacheLookup
	List<WebElement> check_box;*/


	@FindBy(xpath="/html/body/center/form/input[11]")
	@CacheLookup
	WebElement myNumber;

	@FindBy(xpath="/html/body/center/form/input[12]")
	@CacheLookup
	WebElement email;

	@FindBy(how=How.NAME, using="mobile")
	@CacheLookup
	WebElement mobile;

	@FindBy(xpath="/html/body/center/form/input[15]")
	@CacheLookup
	WebElement button;

	@FindBy(xpath="/html/body/center/form/input[16]")
	@CacheLookup
	WebElement clear;

	//getters and setters
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	/*// for company name 
public WebElement getCompanyName() {
	return CompanyName;
}

public void setCompanyName(WebElement companyName) {
	CompanyName = companyName;
}*/


	//  for username
	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName)
	{
	
		this.userName.sendKeys(userName);
	}

	//for city
	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	//for password
	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	//To select a radio button
/*
	public List<WebElement> getRadio_button() {
		return radio_button;
	}


	public void setRadio_button(List<WebElement> radio_button) {
		boolean value=radio_button.get(0).isSelected();
		if(value==true) {
			radio_button.get(1).click();
		}else {
			radio_button.get(0).click();
		}
	}

	// To select a check box
	public List<WebElement> getCheck_box() {
		return check_box;
	}

	public void setCheck_box(List<WebElement> check_box)
	{

		int Size = check_box.size();
		for(int i=0; i < Size ; i++ )
		{
			String sValue = check_box.get(i).getAttribute("value");
			while(sValue.equals("eng")||sValue.equals("tam")){
				check_box.get(i).click();
				break;
			}
		}
	}
*/
	//To enter the hidden

	// To enter my number
	public WebElement getMyNumber() {
		return myNumber;
	}

	public void setMyNumber(String myNumber) {
		this.myNumber.sendKeys(myNumber);
	}

	//To enter email
	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}

	//To enter mobile number
	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}
	//To click the submit button
	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}
	//To click the clear button
	public WebElement getClear() {
		return clear;
	}

	public void setClear() {
		clear.click();
	}


}
